<?php

require_once get_stylesheet_directory() . '/inc/cpts/next_project.php';
require_once get_stylesheet_directory() . '/inc/cpts/python_project.php';
require_once get_stylesheet_directory() . '/inc/cpts/react_project.php';
require_once get_stylesheet_directory() . '/inc/cpts/wp_project.php';

